Case study: http://archive.ics.uci.edu/ml/datasets/heart+Disease

To set up process follow these steps:
1. Open RapidMiner Studio (tested version: 7.6)
2. Select 'Import Process...' option from File Menu
3. Select heart-disease-process.rmp file located inside 'process' folder

To set up process data follow these steps:
1. Navigate to 'Load Data' block
2. For each data block select the right repository entry parameter. Files locations should point to the .data files inside 'data/preprocessed'

Set up is complete, you may now run the model